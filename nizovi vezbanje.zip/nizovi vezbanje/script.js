let br = '7.6';
//parseInt
console.log(parseInt(br), typeof parseInt(br));
//parseFloat
console.log(parseFloat(br), typeof parseFloat(br));

let br1 = 'HIIIIIIIIII'
console.log(parseFloat(br1), typeof parseFloat(br1));

let br2 = '0b1001'
console.log(parseFloat(br2), typeof parseFloat(br2));

let lista= ['mandarina',12,'rec',5.6,true];
//ugradjeni metod forEach()
function print(e, index)
{
    console.log(`Stampa: ${e}, je na poziciji ${index}`);
}
lista.forEach(print);

// filter()
function daLiJeString(e,index){
    return typeof e === 'string';
}
let string = lista.filter(daLiJeString);
console.log(string);
// every()
console.log(lista.every(daLiJeString));

//copyWithin(sta menja, cime menja, kraj sekvence)
lista.copyWithin(0,3,4);
console.log(lista);
lista.copyWithin(1,4);
console.log(lista);

//mapiranje vrednosti niza- map()
let brjevi = [1,2,3,4,5];
let mapnN = brjevi.map( e => e+1);
console.log(mapnN);

// ukloni duplikate koristeci filter i indexof

let ziz = ['Pera','Zika','Mika','Kim','nikola','Pera','Zika','Pera','Zika','Pera','Zika'];

let zuz =ziz.filter((value, index, array) =>{
    console.log(value,index,array.indexOf(value));
    return array.indexOf(value) === index;
});
console.log(zuz);
/*
function filtriranje(value, index, array){
    console.log(value,index,array.indexOf(value));
    return array.indexOf(value) === index;
}

let zuzi = ziz.filter(filtriranje);
*/

//1.kreiraj niz br 
//2. koristici metod niza map() i anonimnu func, vrati azuriran niz 
//monozeci sve br u nizu sa 2
//ispisati u konzoli rezultat
//moze i strlicaste 

let niiz = [2,5,5,6,4,65];

let mapp = niiz.map(e => e*2);

console.log(mapp);

//IIFE
let maap = niiz.map(function(e){
    return e*2;
});
console.log(maap);

//petlja za niz je for of()

for (let br of niiz) {
    console.log(br);
}

//petlja za objekte for in

let cara ={
    model:'Golf', 
    godProiz:'1999',
    boja:'crvena',
    brVrata:3,
};
for(let val in cara){
    console.log(cara[val]);
}

for(let val in cara){
    console.log(val, cara[val]);

}
console.log(cara);

let nizCara= Object.keys(cara);
for( let i = 0; i<nizCara.length;i++)
{
    console.log(nizCara[i]+ ': '+ cara[nizCara[i]]);
}





