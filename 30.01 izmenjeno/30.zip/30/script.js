function promeniatr(){
    let el = document.getElementById('shape');
    el.setAttribute('style','background-color:red;border:1px solid black');
    el.setAttribute('id','new');
    el.setAttribute('class','circle');

}

window.onload = function(){
    document.getElementById("kuce").addEventListener("click",changeColor);
}

function changeColor(){
    let red = Math.floor(Math.random()*256);
    let green = Math.floor(Math.random()*256);
    let blue = Math.floor(Math.random()*256);
    this.style.backgroundColor = `rgb(${red},${green},${blue})`;
}

function addRandNum(){
    let el = document.createElement('p');
    el.innerText = Math.floor(Math.random()*100);
    document.body.appendChild(el);
}