const dugaDiv = document.querySelector('.duga');
const dutton =document.querySelector('.dutton');

const boje =['red','orange','yellow','green','blue','darkblue','purple']
dutton.onclick = function(){
    boje.forEach(function(boja){
        dugaDiv.insertAdjacentHTML('beforeend',`<div style="width: 100px; height:100px; background-color:${boja}" ></div>`)
    })
}

